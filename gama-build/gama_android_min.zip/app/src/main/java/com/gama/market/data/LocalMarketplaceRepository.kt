package com.gama.market.data

import android.content.Context
import com.gama.market.domain.*
import org.json.JSONArray
import org.json.JSONObject

class LocalMarketplaceRepository(context: Context) {
    private val prefs = context.getSharedPreferences("gama_market_store", Context.MODE_PRIVATE)

    fun loadProducts(): List<Product> {
        val raw = prefs.getString("products", null) ?: return FakeCatalog.products
        return runCatching { decodeProducts(JSONArray(raw)) }.getOrElse { FakeCatalog.products }
    }

    fun saveProducts(products: List<Product>) {
        prefs.edit().putString("products", encodeProducts(products).toString()).apply()
    }

    fun loadFavorites(): Set<String> = prefs.getStringSet("favorites", emptySet()).orEmpty()

    fun saveFavorites(ids: Set<String>) {
        prefs.edit().putStringSet("favorites", ids).apply()
    }

    fun loadOffers(): List<Offer> {
        val raw = prefs.getString("offers", null) ?: return emptyList()
        return runCatching { decodeOffers(JSONArray(raw)) }.getOrElse { emptyList() }
    }

    fun saveOffers(offers: List<Offer>) {
        prefs.edit().putString("offers", encodeOffers(offers).toString()).apply()
    }

    fun loadOrders(): List<Order> {
        val raw = prefs.getString("orders", null) ?: return emptyList()
        return runCatching { decodeOrders(JSONArray(raw)) }.getOrElse { emptyList() }
    }

    fun saveOrders(orders: List<Order>) {
        prefs.edit().putString("orders", encodeOrders(orders).toString()).apply()
    }


    fun loadReports(): List<ListingReport> {
        val raw = prefs.getString("reports", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            buildList { repeat(a.length()) { i ->
                val o = a.getJSONObject(i)
                add(ListingReport(
                    id = o.getString("id"), productId = o.getString("productId"),
                    reason = ReportReason.valueOf(o.getString("reason")),
                    note = o.optString("note"), createdAtMillis = o.getLong("createdAt")
                ))
            } }
        }.getOrElse { emptyList() }
    }

    fun saveReports(reports: List<ListingReport>) {
        val a = JSONArray().apply { reports.forEach { r -> put(JSONObject().apply {
            put("id", r.id); put("productId", r.productId); put("reason", r.reason.name);
            put("note", r.note); put("createdAt", r.createdAtMillis)
        }) } }
        prefs.edit().putString("reports", a.toString()).apply()
    }

    fun loadProfile(): UserProfile {
        val raw = prefs.getString("profile", null) ?: return UserProfile()
        return runCatching { decodeProfile(JSONObject(raw)) }.getOrElse { UserProfile() }
    }

    fun saveProfile(profile: UserProfile) {
        prefs.edit().putString("profile", encodeProfile(profile).toString()).apply()
    }

    private fun encodeProducts(products: List<Product>) = JSONArray().apply {
        products.forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("brand", p.brand); put("model", p.model); put("price", p.priceCents)
            put("condition", p.condition.name); put("sellerId", p.sellerId); put("sellerName", p.sellerName)
            put("sellerVerified", p.sellerVerified); put("sellerType", p.sellerType.name); put("location", p.locationLabel); put("description", p.description)
            put("createdAt", p.createdAtMillis)
            put("universe", p.universe.name); put("category", p.category.name)
            put("verification", JSONArray().apply { p.verification.forEach { put(it.name) } })
            put("photos", JSONArray().apply { p.photos.forEach { photo -> put(JSONObject().apply {
                put("kind", photo.kind.name); put("uri", photo.uri); put("sha256", photo.sha256)
            }) } })
        }) }
    }

    private fun decodeProducts(array: JSONArray): List<Product> = buildList {
        repeat(array.length()) { i ->
            val o = array.getJSONObject(i)
            val verificationArray = o.optJSONArray("verification") ?: JSONArray()
            val verification = buildSet {
                repeat(verificationArray.length()) { j ->
                    runCatching { VerificationLevel.valueOf(verificationArray.getString(j)) }.getOrNull()?.let(::add)
                }
            }
            val photoArray = o.optJSONArray("photos") ?: JSONArray()
            val photos = buildList {
                repeat(photoArray.length()) { j ->
                    val po = photoArray.getJSONObject(j)
                    runCatching { PhotoKind.valueOf(po.getString("kind")) }.getOrNull()?.let { kind ->
                        add(ProductPhoto(kind, po.getString("uri"), po.optString("sha256").ifBlank { null }))
                    }
                }
            }
            add(Product(
                id = o.getString("id"), brand = o.getString("brand"), model = o.getString("model"),
                priceCents = o.getInt("price"), condition = ProductCondition.valueOf(o.getString("condition")),
                verification = verification, sellerId = o.optString("sellerId", "seller"),
                sellerName = o.getString("sellerName"), sellerVerified = o.optBoolean("sellerVerified", true),
                sellerType = runCatching { SellerType.valueOf(o.optString("sellerType", SellerType.PRIVATE.name)) }.getOrDefault(SellerType.PRIVATE),
                locationLabel = o.optString("location", "España"), description = o.optString("description"),
                universe = runCatching { MarketUniverse.valueOf(o.optString("universe", MarketUniverse.ECLAT.name)) }.getOrDefault(MarketUniverse.ECLAT),
                category = runCatching { ProductCategory.valueOf(o.optString("category", ProductCategory.BAGS.name)) }.getOrDefault(ProductCategory.BAGS),
                photos = photos, createdAtMillis = o.optLong("createdAt", System.currentTimeMillis())
            ))
        }
    }

    private fun encodeOffers(offers: List<Offer>) = JSONArray().apply {
        offers.forEach { offer -> put(JSONObject().apply {
            put("id", offer.id); put("productId", offer.productId); put("productLabel", offer.productLabel)
            put("amount", offer.amountCents); put("status", offer.status.name); put("createdAt", offer.createdAtMillis)
        }) }
    }

    private fun decodeOffers(array: JSONArray): List<Offer> = buildList {
        repeat(array.length()) { i ->
            val o = array.getJSONObject(i)
            add(Offer(
                id = o.getString("id"), productId = o.getString("productId"), productLabel = o.getString("productLabel"),
                amountCents = o.getInt("amount"), status = OfferStatus.valueOf(o.getString("status")), createdAtMillis = o.getLong("createdAt")
            ))
        }
    }

    private fun encodeOrders(orders: List<Order>) = JSONArray().apply {
        orders.forEach { order -> put(JSONObject().apply {
            put("id", order.id); put("productId", order.productId); put("productLabel", order.productLabel)
            put("amount", order.amountCents); put("status", order.status.name)
            put("createdAt", order.createdAtMillis); put("updatedAt", order.updatedAtMillis)
            put("sellerFee", order.sellerFeeCents); put("buyerFee", order.buyerProtectionFeeCents)
            put("paymentProviderRef", order.paymentProviderRef); put("authenticationRef", order.authenticationRef); put("shippingProviderRef", order.shippingProviderRef)
        }) }
    }

    private fun decodeOrders(array: JSONArray): List<Order> = buildList {
        repeat(array.length()) { i ->
            val o = array.getJSONObject(i)
            add(Order(
                id = o.getString("id"), productId = o.getString("productId"), productLabel = o.getString("productLabel"),
                amountCents = o.getInt("amount"), status = runCatching { TransactionStatus.valueOf(o.getString("status")) }.getOrElse {
                    // V0.4 compatibility: legacy PURCHASED becomes PAYMENT_PENDING.
                    TransactionStatus.PAYMENT_PENDING
                },
                createdAtMillis = o.getLong("createdAt"), updatedAtMillis = o.getLong("updatedAt"),
                sellerFeeCents = o.optInt("sellerFee", 0), buyerProtectionFeeCents = o.optInt("buyerFee", 0),
                paymentProviderRef = o.optString("paymentProviderRef").ifBlank { null },
                authenticationRef = o.optString("authenticationRef").ifBlank { null },
                shippingProviderRef = o.optString("shippingProviderRef").ifBlank { null }
            ))
        }
    }

    private fun encodeProfile(profile: UserProfile) = JSONObject().apply {
        put("id", profile.id); put("name", profile.displayName); put("email", profile.email)
        put("verification", profile.verification.name); put("sales", profile.salesCount); put("purchases", profile.purchasesCount)
        put("universePreference", profile.universePreference.name); put("onboardingComplete", profile.onboardingComplete)
        put("sellerType", profile.sellerType.name); put("foundingSeller", profile.foundingSeller)
    }

    private fun decodeProfile(o: JSONObject) = UserProfile(
        id = o.optString("id", "local-user"), displayName = o.optString("name", "Mi perfil"),
        email = o.optString("email", ""), verification = runCatching {
            AccountVerification.valueOf(o.optString("verification", AccountVerification.UNVERIFIED.name))
        }.getOrDefault(AccountVerification.UNVERIFIED),
        salesCount = o.optInt("sales", 0), purchasesCount = o.optInt("purchases", 0),
        universePreference = runCatching { UniversePreference.valueOf(o.optString("universePreference", UniversePreference.ALL.name)) }.getOrDefault(UniversePreference.ALL),
        onboardingComplete = o.optBoolean("onboardingComplete", false),
        sellerType = runCatching { SellerType.valueOf(o.optString("sellerType", SellerType.PRIVATE.name)) }.getOrDefault(SellerType.PRIVATE),
        foundingSeller = o.optBoolean("foundingSeller", false)
    )
}
