package com.gama.market

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.gama.market.data.MarketplaceViewModel
import com.gama.market.domain.AccountVerification
import com.gama.market.ui.screens.*
import com.gama.market.ui.theme.GamaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GamaRoot() }
    }
}

private data class MainTab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun GamaRoot(vm: MarketplaceViewModel = viewModel()) {
    GamaTheme(vm.universePreference) {
        if (!vm.profile.onboardingComplete) {
            UniverseOnboardingScreen { vm.setUniversePreference(it) }
        } else {
            GamaApp(vm)
        }
    }
}

@Composable
private fun GamaApp(vm: MarketplaceViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val tabs = listOf(
        MainTab("home", "Inicio", Icons.Default.Home),
        MainTab("explore", "Explorar", Icons.Default.Search),
        MainTab("sell", "Vender", Icons.Default.AddCircle),
        MainTab("orders", "Operaciones", Icons.Default.ReceiptLong),
        MainTab("profile", "Perfil", Icons.Default.Person)
    )
    val showBottom = current in tabs.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBottom) NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = current == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo("home") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { outerPadding ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(outerPadding)) {
            composable("home") {
                HomeScreen(
                    products = vm.products,
                    favorites = vm.favoriteIds,
                    preference = vm.universePreference,
                    onPreferenceChange = { vm.setUniversePreference(it, completeOnboarding = false) },
                    onToggleFavorite = vm::toggleFavorite,
                    onOpenProduct = { nav.navigate("product/$it") },
                    onExplore = { nav.navigate("explore") }
                )
            }
            composable("explore") {
                ExploreScreen(
                    products = vm.products,
                    favorites = vm.favoriteIds,
                    preference = vm.universePreference,
                    onPreferenceChange = { vm.setUniversePreference(it, completeOnboarding = false) },
                    onToggleFavorite = vm::toggleFavorite,
                    onOpenProduct = { nav.navigate("product/$it") }
                )
            }
            composable("sell") {
                if (vm.profile.verification == AccountVerification.VERIFIED) {
                    LaunchedEffect(Unit) { vm.trackSellFlowStarted() }
                    SellFlowScreen(
                        initialPreference = vm.universePreference,
                        onBack = { nav.navigate("home") { popUpTo("home") { inclusive = true } } },
                        onPublish = vm::publish
                    )
                } else {
                    SellerGateScreen { nav.navigate("profile") }
                }
            }
            composable("orders") {
                OrdersScreen(
                    offers = vm.offers, orders = vm.orders, onAcceptOfferDebug = vm::acceptOfferDebug,
                    onRejectOfferDebug = vm::rejectOfferDebug, onCheckoutOfferDebug = { vm.checkoutAcceptedOfferDebug(it) },
                    onAdvanceDebug = vm::advanceDebugOrder, onFailAuthenticationDebug = vm::failAuthenticationDebug,
                    onOpenDispute = vm::openDispute,
                    onResolveDisputeDebug = vm::resolveDisputeDebug
                )
            }
            composable("profile") {
                ProfileScreen(
                    profile = vm.profile, onSave = vm::updateProfile, onSellerTypeChange = vm::updateSellerType,
                    onRequestVerification = vm::requestIdentityVerification, onVerifyDebug = vm::verifyIdentityDebug,
                    onMyListings = { nav.navigate("myListings") }, onPrivacy = { nav.navigate("privacy") }
                )
            }
            composable("privacy") { PrivacySecurityScreen { nav.popBackStack() } }
            composable("myListings") {
                MyListingsScreen(
                    products = vm.products.filter { it.sellerId == vm.profile.id }, favorites = vm.favoriteIds,
                    onBack = { nav.popBackStack() }, onOpen = { nav.navigate("product/$it") },
                    onFavorite = vm::toggleFavorite, onRemove = vm::removeOwnListing
                )
            }
            composable(
                route = "product/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                vm.product(id)?.let { product ->
                    LaunchedEffect(id) { vm.trackListingViewed(product) }
                    ProductDetailScreen(
                        product = product, favorite = id in vm.favoriteIds, isOwnListing = product.sellerId == vm.profile.id,
                        onToggleFavorite = { vm.toggleFavorite(id) }, onBack = { nav.popBackStack() },
                        onBuy = { if (vm.createOrder(product) != null) nav.navigate("orders") },
                        onOffer = { amount -> vm.makeOffer(product, amount) },
                        onReport = { reason, note -> vm.reportListing(product.id, reason, note) }
                    )
                }
            }
        }
    }
}
