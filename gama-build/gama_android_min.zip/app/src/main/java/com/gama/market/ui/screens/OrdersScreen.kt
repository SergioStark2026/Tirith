package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.BuildConfig
import com.gama.market.domain.*

@Composable
fun OrdersScreen(
    offers: List<Offer>,
    orders: List<Order>,
    onAcceptOfferDebug: (String) -> Unit,
    onRejectOfferDebug: (String) -> Unit,
    onCheckoutOfferDebug: (String) -> Unit,
    onAdvanceDebug: (String) -> Unit,
    onFailAuthenticationDebug: (String) -> Unit,
    onOpenDispute: (String) -> Boolean,
    onResolveDisputeDebug: (String, Boolean) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Operaciones", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }

        if (offers.isNotEmpty()) {
            item { Text("Ofertas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(offers, key = { it.id }) { offer ->
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(offer.productLabel, fontWeight = FontWeight.Bold)
                        Text(offer.displayAmount)
                        Text(offer.status.label, color = MaterialTheme.colorScheme.secondary)
                        if (BuildConfig.DEBUG && offer.status == OfferStatus.PENDING) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onRejectOfferDebug(offer.id) }) { Text("Rechazar · prueba") }
                                Button(onClick = { onAcceptOfferDebug(offer.id) }) { Text("Aceptar · prueba") }
                            }
                        }
                        if (BuildConfig.DEBUG && offer.status == OfferStatus.ACCEPTED) {
                            Button(onClick = { onCheckoutOfferDebug(offer.id) }) { Text("Pagar oferta · prueba") }
                        }
                    }
                }
            }
        }

        item { Text("Compras", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (orders.isEmpty()) item { Text("Tus compras protegidas aparecerán aquí.") }
        items(orders, key = { it.id }) { order ->
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(order.productLabel, fontWeight = FontWeight.Bold)
                    Text(order.displayAmount)
                    Text(order.status.userLabel(), color = MaterialTheme.colorScheme.secondary)
                    if (order.buyerProtectionFeeCents > 0) Text("Protección GAMA: ${order.buyerProtectionFeeCents / 100} €", style = MaterialTheme.typography.bodySmall)
                    OrderTimeline(order.status)
                    if (order.status in setOf(TransactionStatus.SHIPPED, TransactionStatus.DELIVERED)) {
                        TextButton(onClick = { onOpenDispute(order.id) }) { Text("Tengo un problema") }
                    }
                    if (BuildConfig.DEBUG && order.status in debugAdvanceable) {
                        OutlinedButton(onClick = { onAdvanceDebug(order.id) }) { Text("Avanzar estado · prueba") }
                    }
                    if (BuildConfig.DEBUG && order.status == TransactionStatus.AUTHENTICATION_PENDING) {
                        TextButton(onClick = { onFailAuthenticationDebug(order.id) }) { Text("Simular autenticación fallida · prueba") }
                    }
                    if (BuildConfig.DEBUG && order.status == TransactionStatus.DISPUTED) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onResolveDisputeDebug(order.id, true) }) { Text("Reembolsar · prueba") }
                            Button(onClick = { onResolveDisputeDebug(order.id, false) }) { Text("Cerrar a favor venta · prueba") }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

private val debugAdvanceable = setOf(
    TransactionStatus.PAYMENT_PENDING, TransactionStatus.PAYMENT_AUTHORIZED,
    TransactionStatus.AUTHENTICATION_PENDING, TransactionStatus.AUTHENTICATED,
    TransactionStatus.READY_TO_SHIP, TransactionStatus.SHIPPED, TransactionStatus.DELIVERED,
    TransactionStatus.REFUND_PENDING
)

@Composable
private fun OrderTimeline(status: TransactionStatus) {
    val steps = listOf(
        TransactionStatus.PAYMENT_AUTHORIZED to "Pago protegido",
        TransactionStatus.AUTHENTICATION_PENDING to "Autenticación",
        TransactionStatus.AUTHENTICATED to "Autenticado",
        TransactionStatus.READY_TO_SHIP to "Listo para envío",
        TransactionStatus.SHIPPED to "Enviado",
        TransactionStatus.DELIVERED to "Recibido",
        TransactionStatus.COMPLETED to "Completado"
    )
    val currentIndex = steps.indexOfFirst { it.first == status }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        if (status in setOf(TransactionStatus.AUTHENTICATION_FAILED, TransactionStatus.DISPUTED, TransactionStatus.REFUND_PENDING, TransactionStatus.REFUNDED, TransactionStatus.CANCELLED)) {
            Text(status.userLabel(), color = MaterialTheme.colorScheme.error)
        } else {
            steps.forEachIndexed { index, step -> Text(if (currentIndex >= 0 && index <= currentIndex) "✓ ${step.second}" else "○ ${step.second}") }
        }
    }
}

private fun TransactionStatus.userLabel(): String = when (this) {
    TransactionStatus.PAYMENT_PENDING -> "Esperando confirmación de pago"
    TransactionStatus.PAYMENT_AUTHORIZED -> "Pago protegido"
    TransactionStatus.AUTHENTICATION_PENDING -> "Pendiente de autenticación"
    TransactionStatus.AUTHENTICATED -> "Autenticado"
    TransactionStatus.AUTHENTICATION_FAILED -> "Autenticación fallida"
    TransactionStatus.READY_TO_SHIP -> "Listo para enviar"
    TransactionStatus.SHIPPED -> "Enviado"
    TransactionStatus.DELIVERED -> "Entregado"
    TransactionStatus.DISPUTED -> "Incidencia abierta"
    TransactionStatus.COMPLETED -> "Completado · pago liberado"
    TransactionStatus.REFUND_PENDING -> "Reembolso en curso"
    TransactionStatus.REFUNDED -> "Reembolsado"
    TransactionStatus.CANCELLED -> "Cancelado"
}
