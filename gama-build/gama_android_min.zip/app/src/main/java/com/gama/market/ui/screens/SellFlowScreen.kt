package com.gama.market.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.*
import com.gama.market.util.PhotoQualityResult
import com.gama.market.util.createPhotoUri
import com.gama.market.util.sha256ForUri
import com.gama.market.util.validateListingPhoto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SellFlowScreen(
    initialPreference: UniversePreference,
    onBack: () -> Unit,
    onPublish: (ListingDraft) -> ListingValidation
) {
    var step by remember { mutableIntStateOf(1) }
    var universe by remember {
        mutableStateOf(if (initialPreference == UniversePreference.FORGE) MarketUniverse.FORGE else MarketUniverse.ECLAT)
    }
    var category by remember { mutableStateOf(MarketplacePolicy.categoriesFor(universe).first()) }
    var selectedBrand by remember { mutableStateOf(MarketplacePolicy.brandsFor(category).first()) }
    var model by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("400") }
    var condition by remember { mutableStateOf(ProductCondition.VERY_GOOD) }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("España") }
    val photos = remember { mutableStateMapOf<PhotoKind, ProductPhoto>() }
    var error by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var checkingPhoto by remember { mutableStateOf(false) }
    var pendingKind by remember { mutableStateOf<PhotoKind?>(null) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }

    fun setUniverse(next: MarketUniverse) {
        universe = next
        category = MarketplacePolicy.categoriesFor(next).first()
        selectedBrand = MarketplacePolicy.brandsFor(category).first()
    }
    fun setCategory(next: ProductCategory) {
        category = next
        selectedBrand = MarketplacePolicy.brandsFor(next).first()
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val kind = pendingKind; val uri = pendingUri
        if (success && kind != null && uri != null) {
            checkingPhoto = true
            scope.launch {
                when (val quality = withContext(Dispatchers.IO) { validateListingPhoto(context, uri) }) {
                    PhotoQualityResult.Good -> {
                        photos[kind] = ProductPhoto(kind, uri.toString(), sha256ForUri(context, uri))
                        error = null
                    }
                    is PhotoQualityResult.Bad -> error = quality.reason
                }
                checkingPhoto = false
            }
        }
        pendingKind = null; pendingUri = null
    }

    fun capture(kind: PhotoKind) {
        val uri = createPhotoUri(context)
        pendingKind = kind; pendingUri = uri; camera.launch(uri)
    }

    fun draft() = ListingDraft(
        brand = selectedBrand, model = model, priceCents = (price.toIntOrNull() ?: 0) * 100,
        condition = condition, description = description, locationLabel = location,
        photos = PhotoKind.entries.mapNotNull { kind -> photos[kind] },
        universe = universe, category = category
    )

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = if (step == 1) onBack else ({ step-- })) { Text(if (step == 1) "Cancelar" else "Atrás") }
                Text("Publicar pieza", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                LinearProgressIndicator(progress = { step / 4f }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp)); Text("Paso $step de 4", color = MaterialTheme.colorScheme.secondary)
            }
            when (step) {
                1 -> item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Identifica la pieza", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MarketUniverse.entries.forEach { u -> FilterChip(selected = universe == u, onClick = { setUniverse(u) }, label = { Text(u.label) }) }
                        }
                        CategoryPicker(universe, category, ::setCategory)
                        BrandPicker(category, selectedBrand) { selectedBrand = it }
                        OutlinedTextField(model, { model = it }, label = { Text("Modelo") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Precio (€)") }, supportingText = { Text("Mínimo: 400 €") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val validation = when {
                                model.trim().length < 2 -> "Indica el modelo"
                                (price.toIntOrNull() ?: 0) * 100 < MarketplacePolicy.MIN_LISTING_PRICE_CENTS -> "El precio mínimo es 400 €"
                                else -> null
                            }
                            error = validation; if (validation == null) step = 2
                        }, modifier = Modifier.fillMaxWidth()) { Text("Continuar") }
                    }
                }
                2 -> {
                    item { Text("Fotos guiadas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Seis tomas desde cámara para documentar la pieza.") }
                    items(PhotoKind.entries) { kind ->
                        OutlinedCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(kind.label, fontWeight = FontWeight.Bold); Text(kind.hint, style = MaterialTheme.typography.bodySmall)
                                    if (photos[kind] != null) Text("✓ Capturada", color = MaterialTheme.colorScheme.secondary)
                                }
                                Button(onClick = { capture(kind) }) { Text(if (photos[kind] == null) "Foto" else "Repetir") }
                            }
                        }
                    }
                    item {
                        if (checkingPhoto) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (photos.size == PhotoKind.entries.size) { error = null; step = 3 }
                            else error = "Faltan ${PhotoKind.entries.size - photos.size} fotos obligatorias"
                        }, enabled = !checkingPhoto, modifier = Modifier.fillMaxWidth()) { Text("Continuar") }
                    }
                }
                3 -> item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Estado y descripción", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        ProductCondition.entries.forEach { c -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = c == condition, onClick = { condition = c }); Text(c.label) } }
                        OutlinedTextField(description, { description = it }, label = { Text("Descripción") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(location, { location = it }, label = { Text("Ubicación") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { if (description.trim().length >= 20) { error = null; step = 4 } else error = "Describe el artículo con al menos 20 caracteres" }, modifier = Modifier.fillMaxWidth()) { Text("Revisar") }
                    }
                }
                4 -> item {
                    val d = draft()
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Revisión", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("${d.universe.label} · ${d.category.label}", color = MaterialTheme.colorScheme.secondary)
                        Text("${d.brand} · ${d.model}"); Text("${d.priceCents / 100} € · ${d.condition.label}"); Text("${d.photos.size} fotos guiadas"); Text(d.description)
                        val authRoute = TrustPolicy.authenticationRoute(d.category, d.priceCents)
                        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Autenticación prevista", fontWeight = FontWeight.Bold)
                                Text(authRoute.label)
                                Text("La pieza no se completa hasta superar los controles aplicables.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Button(onClick = {
                            when (val result = onPublish(d)) {
                                ListingValidation.Valid -> onBack()
                                is ListingValidation.Invalid -> error = result.reason
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Publicar") }
                    }
                }
            }
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            item { Spacer(Modifier.height(70.dp)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryPicker(universe: MarketUniverse, selected: ProductCategory, onSelected: (ProductCategory) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val options = MarketplacePolicy.categoriesFor(universe)
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value = selected.label, onValueChange = {}, readOnly = true, label = { Text("Categoría") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) { options.forEach { c -> DropdownMenuItem(text = { Text(c.label) }, onClick = { onSelected(c); expanded = false }) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BrandPicker(category: ProductCategory, selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded, { expanded = !expanded }) {
        OutlinedTextField(value = selected, onValueChange = {}, readOnly = true, label = { Text("Marca") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).fillMaxWidth())
        ExposedDropdownMenu(expanded, { expanded = false }) { MarketplacePolicy.brandsFor(category).forEach { brand -> DropdownMenuItem(text = { Text(brand) }, onClick = { onSelected(brand); expanded = false }) } }
    }
}
