package com.gama.market.integrations

import com.gama.market.domain.*

sealed interface ExternalResult<out T> {
    data class Success<T>(val value: T) : ExternalResult<T>
    data class Unavailable(val reason: String) : ExternalResult<Nothing>
    data class Failure(val reason: String) : ExternalResult<Nothing>
}

/** Provider-hosted/tokenized KYC. Android never receives raw identity-document bytes. */
interface IdentityProvider {
    suspend fun startVerification(user: UserProfile): ExternalResult<ProviderSession>
}

/** Marketplace PSP. GAMA only handles provider references and states, never card or bank credentials. */
interface PaymentProvider {
    suspend fun startCheckout(product: Product, fees: FeeBreakdown): ExternalResult<ProviderSession>
}

/** Authentication provider or approved physical partner routing. */
interface AuthenticationProvider {
    suspend fun startAuthentication(product: Product, route: AuthenticationRoute): ExternalResult<ProviderSession>
}

interface ShippingProvider {
    suspend fun createShipment(order: Order): ExternalResult<ProviderSession>
}

data class ProviderSession(val providerRef: String, val redirectUrl: String? = null)

object IntegrationStatus {
    const val BACKEND_CONFIGURED = false
    const val KYC_CONFIGURED = false
    const val PAYMENTS_CONFIGURED = false
    const val AUTHENTICATION_CONFIGURED = false
    const val SHIPPING_CONFIGURED = false

    val productionReady: Boolean
        get() = BACKEND_CONFIGURED && KYC_CONFIGURED && PAYMENTS_CONFIGURED && AUTHENTICATION_CONFIGURED && SHIPPING_CONFIGURED
}
