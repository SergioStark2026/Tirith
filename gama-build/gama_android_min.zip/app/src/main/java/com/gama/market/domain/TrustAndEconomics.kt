package com.gama.market.domain

enum class SellerType(val label: String) {
    PRIVATE("Particular"), PROFESSIONAL("Profesional")
}

enum class AuthenticationRoute(val label: String) {
    DIGITAL("Autenticación digital"),
    DIGITAL_PLUS_FINGERPRINT("Digital + huella del artículo"),
    PHYSICAL_PARTNER("Certificación física por especialista")
}

data class FeeBreakdown(
    val itemPriceCents: Int,
    val sellerFeeCents: Int,
    val buyerProtectionFeeCents: Int,
    val buyerTotalCents: Int,
    val sellerReceivesCents: Int
)

object MarketplaceEconomics {
    const val SELLER_FEE_BPS = 800 // 8.00%
    const val BUYER_PROTECTION_FEE_BPS = 300 // 3.00%

    fun fees(itemPriceCents: Int): FeeBreakdown {
        require(itemPriceCents > 0)
        val sellerFee = ((itemPriceCents.toLong() * SELLER_FEE_BPS) / 10_000L).toInt()
        val buyerFee = ((itemPriceCents.toLong() * BUYER_PROTECTION_FEE_BPS) / 10_000L).toInt()
        return FeeBreakdown(
            itemPriceCents = itemPriceCents,
            sellerFeeCents = sellerFee,
            buyerProtectionFeeCents = buyerFee,
            buyerTotalCents = itemPriceCents + buyerFee,
            sellerReceivesCents = itemPriceCents - sellerFee
        )
    }
}

object TrustPolicy {
    // Relojes de ticket alto salen del flujo exclusivamente fotográfico.
    const val WATCH_PHYSICAL_REVIEW_THRESHOLD_CENTS = 300_000

    fun authenticationRoute(product: Product): AuthenticationRoute = authenticationRoute(product.category, product.priceCents)

    fun authenticationRoute(category: ProductCategory, priceCents: Int): AuthenticationRoute = when (category) {
        ProductCategory.WATCHES -> if (priceCents >= WATCH_PHYSICAL_REVIEW_THRESHOLD_CENTS) {
            AuthenticationRoute.PHYSICAL_PARTNER
        } else {
            AuthenticationRoute.DIGITAL_PLUS_FINGERPRINT
        }
        ProductCategory.BAGS, ProductCategory.FASHION_ACCESSORIES -> AuthenticationRoute.DIGITAL_PLUS_FINGERPRINT
        ProductCategory.PREMIUM_TECH -> AuthenticationRoute.DIGITAL
    }

    fun canReleaseSellerFunds(status: TransactionStatus): Boolean = status == TransactionStatus.COMPLETED
}

/**
 * Privacy-by-design contract. The app/backend stores provider references, never raw regulated credentials.
 */
object DataMinimizationPolicy {
    val forbiddenPersistentFields = setOf(
        "card_number", "card_cvc", "bank_account", "iban_full", "passport_image", "dni_image", "kyc_document_bytes"
    )

    fun mayPersist(fieldName: String): Boolean = fieldName.lowercase() !in forbiddenPersistentFields
}
