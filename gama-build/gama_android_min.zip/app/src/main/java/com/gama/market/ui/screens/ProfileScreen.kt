package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.BuildConfig
import com.gama.market.domain.*
import com.gama.market.integrations.IntegrationStatus

@Composable
fun ProfileScreen(
    profile: UserProfile,
    onSave: (String, String) -> Unit,
    onSellerTypeChange: (SellerType) -> Unit,
    onRequestVerification: () -> Unit,
    onVerifyDebug: () -> Unit,
    onMyListings: () -> Unit,
    onPrivacy: () -> Unit
) {
    var name by remember(profile.displayName) { mutableStateOf(profile.displayName) }
    var email by remember(profile.email) { mutableStateOf(profile.email) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Perfil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it }, label = { Text("Nombre visible") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { onSave(name, email) }, modifier = Modifier.fillMaxWidth()) { Text("Guardar") }

        Text("Tipo de vendedor", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SellerType.entries.forEach { type ->
                FilterChip(selected = profile.sellerType == type, onClick = { onSellerTypeChange(type) }, label = { Text(type.label) })
            }
        }
        if (profile.foundingSeller) AssistChip(onClick = {}, label = { Text("Founder Seller") })

        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Confianza", fontWeight = FontWeight.Bold)
                Text(profile.verification.label)
                when (profile.verification) {
                    AccountVerification.UNVERIFIED -> OutlinedButton(onClick = onRequestVerification) { Text("Verificar identidad") }
                    AccountVerification.PENDING -> Text(if (IntegrationStatus.KYC_CONFIGURED) "Proceso iniciado" else "Proveedor KYC pendiente de conectar")
                    AccountVerification.VERIFIED -> Text("✓ Verificada")
                }
                if (BuildConfig.DEBUG && profile.verification != AccountVerification.VERIFIED) {
                    TextButton(onClick = onVerifyDebug) { Text("Marcar verificado · prueba") }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Publicaciones: ${profile.salesCount}")
            Text("Compras: ${profile.purchasesCount}")
        }
        OutlinedButton(onClick = onMyListings, modifier = Modifier.fillMaxWidth()) { Text("Mis anuncios") }
        OutlinedButton(onClick = onPrivacy, modifier = Modifier.fillMaxWidth()) { Text("Privacidad y seguridad") }
        HorizontalDivider()
        Text("Integraciones", fontWeight = FontWeight.Bold)
        Text("Pagos: ${if (IntegrationStatus.PAYMENTS_CONFIGURED) "activo" else "pendiente de credenciales"}")
        Text("Autenticación: ${if (IntegrationStatus.AUTHENTICATION_CONFIGURED) "activa" else "pendiente de proveedor"}")
    }
}
