package com.gama.market.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.gama.market.domain.*
import com.gama.market.integrations.*
import java.util.UUID

class MarketplaceViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = LocalMarketplaceRepository(application)
    private val analytics: AnalyticsProvider = LocalAnalyticsProvider(application)

    var products by mutableStateOf(repo.loadProducts()); private set
    var favoriteIds by mutableStateOf(repo.loadFavorites()); private set
    var offers by mutableStateOf(repo.loadOffers()); private set
    var orders by mutableStateOf(repo.loadOrders()); private set
    var profile by mutableStateOf(repo.loadProfile()); private set
    var reports by mutableStateOf(repo.loadReports()); private set
    var universePreference by mutableStateOf(profile.universePreference); private set

    init {
        analytics.track(AnalyticsEvent(AnalyticsEventName.APP_OPEN))
    }

    fun trackListingViewed(product: Product) {
        analytics.track(AnalyticsEvent(AnalyticsEventName.LISTING_VIEWED, universe = product.universe, listingId = product.id))
    }

    fun trackSellFlowStarted() {
        analytics.track(AnalyticsEvent(AnalyticsEventName.SELL_FLOW_STARTED))
    }

    fun setUniversePreference(preference: UniversePreference, completeOnboarding: Boolean = true) {
        universePreference = preference
        profile = profile.copy(universePreference = preference, onboardingComplete = profile.onboardingComplete || completeOnboarding)
        repo.saveProfile(profile)
        analytics.track(AnalyticsEvent(AnalyticsEventName.UNIVERSE_SELECTED, universe = when (preference) {
            UniversePreference.ECLAT -> MarketUniverse.ECLAT
            UniversePreference.FORGE -> MarketUniverse.FORGE
            UniversePreference.ALL -> null
        }))
    }

    fun product(id: String): Product? = products.firstOrNull { it.id == id }

    fun toggleFavorite(id: String) {
        favoriteIds = if (id in favoriteIds) favoriteIds - id else favoriteIds + id
        repo.saveFavorites(favoriteIds)
        analytics.track(AnalyticsEvent(AnalyticsEventName.FAVORITE_TOGGLED, listingId = id))
    }

    fun publish(draft: ListingDraft): ListingValidation {
        if (profile.verification != AccountVerification.VERIFIED) {
            return ListingValidation.Invalid("Debes verificar tu identidad antes de publicar")
        }
        val validation = MarketplacePolicy.validateListing(draft)
        if (validation is ListingValidation.Invalid) return validation
        val product = Product(
            id = UUID.randomUUID().toString(), brand = draft.brand, model = draft.model.trim(),
            priceCents = draft.priceCents, condition = draft.condition,
            universe = draft.universe, category = draft.category,
            verification = setOf(VerificationLevel.IDENTITY), sellerId = profile.id,
            sellerName = profile.displayName.ifBlank { "Vendedor" }, sellerVerified = true, sellerType = profile.sellerType,
            locationLabel = draft.locationLabel.ifBlank { "España" }, description = draft.description.trim(), photos = draft.photos
        )
        products = listOf(product) + products
        profile = profile.copy(salesCount = profile.salesCount + 1)
        repo.saveProducts(products); repo.saveProfile(profile)
        analytics.track(AnalyticsEvent(AnalyticsEventName.LISTING_PUBLISHED, universe = product.universe, listingId = product.id))
        return ListingValidation.Valid
    }

    fun removeOwnListing(productId: String): Boolean {
        val product = products.firstOrNull { it.id == productId } ?: return false
        if (product.sellerId != profile.id) return false
        val hasActiveOrder = orders.any {
            it.productId == productId && it.status !in setOf(TransactionStatus.COMPLETED, TransactionStatus.REFUNDED, TransactionStatus.CANCELLED)
        }
        if (hasActiveOrder) return false
        products = products.filterNot { it.id == productId }
        favoriteIds = favoriteIds - productId
        offers = offers.map {
            if (it.productId == productId && it.status == OfferStatus.PENDING) it.copy(status = OfferStatus.CANCELLED) else it
        }
        repo.saveProducts(products); repo.saveFavorites(favoriteIds); repo.saveOffers(offers)
        return true
    }

    fun makeOffer(product: Product, amountCents: Int): Boolean {
        if (product.sellerId == profile.id) return false
        if (offers.any { it.productId == product.id && it.status == OfferStatus.PENDING }) return false
        if (!MarketplacePolicy.isOfferAllowed(product.priceCents, amountCents)) return false
        val offer = Offer(
            id = UUID.randomUUID().toString(), productId = product.id,
            productLabel = "${product.brand} ${product.model}", amountCents = amountCents,
            status = OfferStatus.PENDING, createdAtMillis = System.currentTimeMillis()
        )
        offers = listOf(offer) + offers
        repo.saveOffers(offers)
        analytics.track(AnalyticsEvent(AnalyticsEventName.OFFER_CREATED, universe = product.universe, listingId = product.id))
        return true
    }

    fun createOrder(product: Product, amountCents: Int = product.priceCents): Order? {
        if (product.sellerId == profile.id) return null
        if (amountCents <= 0 || amountCents > product.priceCents) return null
        if (orders.any { it.productId == product.id && it.status !in setOf(TransactionStatus.COMPLETED, TransactionStatus.REFUNDED, TransactionStatus.CANCELLED) }) return null
        analytics.track(AnalyticsEvent(AnalyticsEventName.CHECKOUT_STARTED, universe = product.universe, listingId = product.id))
        val now = System.currentTimeMillis()
        val fees = MarketplaceEconomics.fees(amountCents)
        val order = Order(
            id = UUID.randomUUID().toString(), productId = product.id, productLabel = "${product.brand} ${product.model}",
            amountCents = amountCents, status = TransactionStatus.PAYMENT_PENDING,
            createdAtMillis = now, updatedAtMillis = now,
            sellerFeeCents = fees.sellerFeeCents, buyerProtectionFeeCents = fees.buyerProtectionFeeCents
        )
        orders = listOf(order) + orders
        repo.saveOrders(orders)
        analytics.track(AnalyticsEvent(AnalyticsEventName.ORDER_CREATED, universe = product.universe, listingId = product.id, orderId = order.id))
        return order
    }

    fun acceptOfferDebug(offerId: String) {
        offers = offers.map { if (it.id == offerId && it.status == OfferStatus.PENDING) it.copy(status = OfferStatus.ACCEPTED) else it }
        repo.saveOffers(offers)
    }

    fun rejectOfferDebug(offerId: String) {
        offers = offers.map { if (it.id == offerId && it.status == OfferStatus.PENDING) it.copy(status = OfferStatus.REJECTED) else it }
        repo.saveOffers(offers)
    }

    fun checkoutAcceptedOfferDebug(offerId: String): Order? {
        val offer = offers.firstOrNull { it.id == offerId && it.status == OfferStatus.ACCEPTED } ?: return null
        if (orders.any { it.productId == offer.productId && it.amountCents == offer.amountCents }) return null
        val product = product(offer.productId) ?: return null
        return createOrder(product, offer.amountCents)
    }

    fun advanceDebugOrder(orderId: String) {
        val order = orders.firstOrNull { it.id == orderId } ?: return
        val next = when (order.status) {
            TransactionStatus.PAYMENT_PENDING -> TransactionStatus.PAYMENT_AUTHORIZED
            TransactionStatus.PAYMENT_AUTHORIZED -> TransactionStatus.AUTHENTICATION_PENDING
            TransactionStatus.AUTHENTICATION_PENDING -> TransactionStatus.AUTHENTICATED
            TransactionStatus.AUTHENTICATED -> TransactionStatus.READY_TO_SHIP
            TransactionStatus.READY_TO_SHIP -> TransactionStatus.SHIPPED
            TransactionStatus.SHIPPED -> TransactionStatus.DELIVERED
            TransactionStatus.DELIVERED -> TransactionStatus.COMPLETED
            TransactionStatus.REFUND_PENDING -> TransactionStatus.REFUNDED
            else -> null
        } ?: return
        if (!TransactionFlow.canTransition(order.status, next)) return
        orders = orders.map { if (it.id == orderId) it.copy(status = next, updatedAtMillis = System.currentTimeMillis()) else it }
        repo.saveOrders(orders)
        if (next == TransactionStatus.COMPLETED) {
            profile = profile.copy(purchasesCount = profile.purchasesCount + 1)
            repo.saveProfile(profile)
            analytics.track(AnalyticsEvent(AnalyticsEventName.ORDER_COMPLETED, orderId = order.id))
        }
    }

    fun failAuthenticationDebug(orderId: String) {
        val order = orders.firstOrNull { it.id == orderId && it.status == TransactionStatus.AUTHENTICATION_PENDING } ?: return
        if (!TransactionFlow.canTransition(order.status, TransactionStatus.AUTHENTICATION_FAILED)) return
        orders = orders.map { if (it.id == orderId) it.copy(status = TransactionStatus.AUTHENTICATION_FAILED, updatedAtMillis = System.currentTimeMillis()) else it }
        repo.saveOrders(orders)
    }

    fun openDispute(orderId: String): Boolean {
        val order = orders.firstOrNull { it.id == orderId } ?: return false
        if (!TransactionFlow.canTransition(order.status, TransactionStatus.DISPUTED)) return false
        orders = orders.map { if (it.id == orderId) it.copy(status = TransactionStatus.DISPUTED, updatedAtMillis = System.currentTimeMillis()) else it }
        repo.saveOrders(orders)
        return true
    }

    fun resolveDisputeDebug(orderId: String, refund: Boolean) {
        val order = orders.firstOrNull { it.id == orderId && it.status == TransactionStatus.DISPUTED } ?: return
        val next = if (refund) TransactionStatus.REFUND_PENDING else TransactionStatus.COMPLETED
        if (!TransactionFlow.canTransition(order.status, next)) return
        orders = orders.map { if (it.id == orderId) it.copy(status = next, updatedAtMillis = System.currentTimeMillis()) else it }
        repo.saveOrders(orders)
    }

    fun reportListing(productId: String, reason: ReportReason, note: String): Boolean {
        if (productId.isBlank()) return false
        val report = ListingReport(
            id = UUID.randomUUID().toString(), productId = productId, reason = reason,
            note = note.trim().take(500), createdAtMillis = System.currentTimeMillis()
        )
        reports = listOf(report) + reports
        repo.saveReports(reports)
        return true
    }

    fun updateProfile(name: String, email: String) {
        profile = profile.copy(displayName = name.trim().ifBlank { "Mi perfil" }, email = email.trim())
        repo.saveProfile(profile)
    }

    fun updateSellerType(type: SellerType) {
        profile = profile.copy(sellerType = type)
        repo.saveProfile(profile)
    }

    fun requestIdentityVerification() {
        if (profile.verification == AccountVerification.UNVERIFIED) {
            profile = profile.copy(verification = AccountVerification.PENDING)
            repo.saveProfile(profile)
        }
    }

    fun verifyIdentityDebug() {
        profile = profile.copy(verification = AccountVerification.VERIFIED)
        repo.saveProfile(profile)
    }
}
