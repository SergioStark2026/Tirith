package com.gama.market.util

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

fun createPhotoUri(context: Context): Uri {
    val dir = File(context.filesDir, "listing_photos").apply { mkdirs() }
    val file = File(dir, "gama_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}
