package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.*
import com.gama.market.ui.components.ProductCard

@Composable
fun HomeScreen(
    products: List<Product>,
    favorites: Set<String>,
    preference: UniversePreference,
    onPreferenceChange: (UniversePreference) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onOpenProduct: (String) -> Unit,
    onExplore: () -> Unit
) {
    val visible = products.filter { preference == UniversePreference.ALL || it.universe.name == preference.name }
    val heroTitle = when (preference) {
        UniversePreference.ECLAT -> "ÉCLAT"
        UniversePreference.FORGE -> "FORGE"
        UniversePreference.ALL -> "GAMA"
    }
    val heroCopy = when (preference) {
        UniversePreference.ECLAT -> "Piezas con presencia. Confianza antes que impulso."
        UniversePreference.FORGE -> "Precisión, materiales y tecnología con trazabilidad."
        UniversePreference.ALL -> "Lujo de segunda mano, seleccionado y verificable."
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(heroTitle, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
            Text(heroCopy, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(16.dp))
            UniverseSwitcher(preference, onPreferenceChange)
        }
        item {
            Surface(color = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary, shape = RoundedCornerShape(28.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Selección privada", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Vendedores identificados · ofertas controladas · autenticación visible")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onExplore) { Text("Explorar catálogo") }
                }
            }
        }
        item {
            Text("Destacados", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        items(visible.take(4), key = { it.id }) { product ->
            ProductCard(product, product.id in favorites, { onToggleFavorite(product.id) }, { onOpenProduct(product.id) })
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}

@Composable
fun UniverseSwitcher(selected: UniversePreference, onSelected: (UniversePreference) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        UniversePreference.entries.forEach { item ->
            FilterChip(selected = selected == item, onClick = { onSelected(item) }, label = { Text(item.label) })
        }
    }
}
