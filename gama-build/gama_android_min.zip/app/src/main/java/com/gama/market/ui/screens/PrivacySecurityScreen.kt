package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun PrivacySecurityScreen(onBack: () -> Unit) {
    Scaffold(topBar = {
        Row(Modifier.fillMaxWidth().padding(12.dp)) {
            TextButton(onClick = onBack) { Text("Atrás") }
            Text("Privacidad y seguridad", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("GAMA guarda el mínimo dato necesario.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
            item { Text("No almacenamos números de tarjeta, CVC, cuentas bancarias ni imágenes de documentos de identidad. Esos datos permanecen en proveedores regulados especializados.") }
            item { SecurityLine("Pagos", "Tokenizados y gestionados por proveedor externo; GAMA solo recibe referencias y estados.") }
            item { SecurityLine("Identidad", "La verificación KYC se realiza fuera de GAMA; conservamos únicamente el resultado y la referencia del proveedor.") }
            item { SecurityLine("Autenticación del producto", "Guardamos el estado/certificado de la operación, no bases biométricas ni secretos del proveedor.") }
            item { SecurityLine("Administración", "Acceso privado con MFA, permisos por rol y trazabilidad de acciones.") }
            item { Text("En producción añadiremos desde esta pantalla descarga de datos, cierre de sesión en otros dispositivos y solicitud de eliminación de cuenta mediante endpoints autenticados.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun SecurityLine(title: String, copy: String) {
    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontWeight = FontWeight.Bold); Text(copy)
    } }
}
