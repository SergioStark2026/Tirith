package com.gama.market.integrations

import com.gama.market.domain.MarketUniverse

enum class AnalyticsEventName {
    APP_OPEN, UNIVERSE_SELECTED, LISTING_VIEWED, FAVORITE_TOGGLED,
    SELL_FLOW_STARTED, LISTING_PUBLISHED, OFFER_CREATED,
    CHECKOUT_STARTED, ORDER_CREATED, ORDER_COMPLETED
}

data class AnalyticsEvent(
    val name: AnalyticsEventName,
    val universe: MarketUniverse? = null,
    val listingId: String? = null,
    val orderId: String? = null,
    val properties: Map<String, String> = emptyMap()
)

interface AnalyticsProvider {
    fun track(event: AnalyticsEvent)
}

/** Safe default for the local MVP. Replace with the production analytics endpoint later. */
object NoOpAnalyticsProvider : AnalyticsProvider {
    override fun track(event: AnalyticsEvent) = Unit
}
