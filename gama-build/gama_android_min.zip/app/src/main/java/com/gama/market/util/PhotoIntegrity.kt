package com.gama.market.util

import android.content.Context
import android.net.Uri
import java.security.MessageDigest

fun sha256ForUri(context: Context, uri: Uri): String? = runCatching {
    val digest = MessageDigest.getInstance("SHA-256")
    context.contentResolver.openInputStream(uri)?.use { input ->
        val buffer = ByteArray(8192)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            digest.update(buffer, 0, read)
        }
    } ?: return null
    digest.digest().joinToString("") { "%02x".format(it) }
}.getOrNull()
