package com.gama.market.data

import android.content.Context
import com.gama.market.integrations.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Local debug analytics with strict minimization. Production swaps this for the authenticated analytics endpoint. */
class LocalAnalyticsProvider(context: Context) : AnalyticsProvider {
    private val prefs = context.getSharedPreferences("gama_analytics", Context.MODE_PRIVATE)
    private val sessionId = UUID.randomUUID().toString()

    override fun track(event: AnalyticsEvent) {
        val raw = prefs.getString("events", "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        arr.put(JSONObject().apply {
            put("event", event.name.name)
            put("session", sessionId)
            put("universe", event.universe?.name)
            put("listingId", event.listingId)
            put("orderId", event.orderId)
            put("createdAt", System.currentTimeMillis())
            put("properties", JSONObject(event.properties))
        })
        // Keep only a bounded local debug trail.
        val trimmed = JSONArray()
        val start = (arr.length() - 500).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("events", trimmed.toString()).apply()
    }
}
