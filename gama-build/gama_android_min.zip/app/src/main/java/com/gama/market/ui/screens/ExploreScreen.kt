package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.*
import com.gama.market.ui.components.ProductCard

@Composable
fun ExploreScreen(
    products: List<Product>, favorites: Set<String>, preference: UniversePreference,
    onPreferenceChange: (UniversePreference) -> Unit, onToggleFavorite: (String) -> Unit, onOpenProduct: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<ProductCategory?>(null) }
    var condition by remember { mutableStateOf<ProductCondition?>(null) }
    var favoritesOnly by remember { mutableStateOf(false) }
    var verifiedOnly by remember { mutableStateOf(false) }
    var maxPrice by remember { mutableStateOf("") }

    val availableCategories = ProductCategory.entries.filter { preference == UniversePreference.ALL || it.universe.name == preference.name }
    LaunchedEffect(preference) { if (category !in availableCategories) category = null }
    val maxPriceCents = maxPrice.toIntOrNull()?.times(100)

    val filtered = products.filter {
        (preference == UniversePreference.ALL || it.universe.name == preference.name) &&
            (category == null || it.category == category) &&
            (condition == null || it.condition == condition) &&
            (!favoritesOnly || it.id in favorites) &&
            (!verifiedOnly || it.sellerVerified) &&
            (maxPriceCents == null || it.priceCents <= maxPriceCents) &&
            (query.isBlank() || "${it.brand} ${it.model} ${it.category.label}".contains(query, true))
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Explorar", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            UniverseSwitcher(preference, onPreferenceChange)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(query, { query = it }, label = { Text("Buscar marca, modelo o categoría") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = category == null, onClick = { category = null }, label = { Text("Todo") })
                availableCategories.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c.label) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProductCondition.entries.forEach { c -> FilterChip(selected = condition == c, onClick = { condition = if (condition == c) null else c }, label = { Text(c.label) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = !favoritesOnly }, label = { Text("Favoritos") })
                FilterChip(selected = verifiedOnly, onClick = { verifiedOnly = !verifiedOnly }, label = { Text("Vendedor verificado") })
            }
            OutlinedTextField(
                maxPrice, { maxPrice = it.filter(Char::isDigit) }, label = { Text("Precio máximo (€)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Text("${filtered.size} piezas", color = MaterialTheme.colorScheme.secondary)
        }
        if (filtered.isEmpty()) item { Text("No hay piezas con estos filtros.") }
        items(filtered, key = { it.id }) { p -> ProductCard(p, p.id in favorites, { onToggleFavorite(p.id) }, { onOpenProduct(p.id) }) }
        item { Spacer(Modifier.height(70.dp)) }
    }
}
