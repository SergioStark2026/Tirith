package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.Product
import com.gama.market.ui.components.ProductCard

@Composable
fun FavoritesScreen(
    products: List<Product>,
    favorites: Set<String>,
    onToggleFavorite: (String) -> Unit,
    onOpenProduct: (String) -> Unit
) {
    val items = products.filter { it.id in favorites }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Favoritos", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        if (items.isEmpty()) item { Text("Guarda artículos para encontrarlos aquí.") }
        items(items, key = { it.id }) { p ->
            ProductCard(p, true, { onToggleFavorite(p.id) }, { onOpenProduct(p.id) })
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}
