package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.Product
import com.gama.market.ui.components.ProductCard

@Composable
fun MyListingsScreen(
    products: List<Product>,
    favorites: Set<String>,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onFavorite: (String) -> Unit,
    onRemove: (String) -> Boolean
) {
    var pendingRemoval by remember { mutableStateOf<Product?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp)) {
                TextButton(onClick = onBack) { Text("Atrás") }
                Text("Mis anuncios", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            if (products.isEmpty()) item { Text("Todavía no has publicado ningún artículo.") }
            items(products, key = { it.id }) { product ->
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProductCard(product, product.id in favorites, { onFavorite(product.id) }, { onOpen(product.id) })
                    TextButton(onClick = { pendingRemoval = product }) { Text("Retirar anuncio") }
                }
            }
        }
    }

    pendingRemoval?.let { product ->
        AlertDialog(
            onDismissRequest = { pendingRemoval = null },
            title = { Text("Retirar anuncio") },
            text = { Text("${product.brand} ${product.model} dejará de aparecer en el catálogo.") },
            confirmButton = {
                TextButton(onClick = {
                    if (onRemove(product.id)) error = null else error = "No puedes retirar un artículo con una operación activa."
                    pendingRemoval = null
                }) { Text("Retirar") }
            },
            dismissButton = { TextButton(onClick = { pendingRemoval = null }) { Text("Cancelar") } }
        )
    }
}
