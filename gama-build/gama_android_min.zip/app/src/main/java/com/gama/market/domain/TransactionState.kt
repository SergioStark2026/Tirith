package com.gama.market.domain

enum class TransactionStatus {
    PAYMENT_PENDING,
    PAYMENT_AUTHORIZED,
    AUTHENTICATION_PENDING,
    AUTHENTICATED,
    AUTHENTICATION_FAILED,
    READY_TO_SHIP,
    SHIPPED,
    DELIVERED,
    DISPUTED,
    COMPLETED,
    REFUND_PENDING,
    REFUNDED,
    CANCELLED
}

object TransactionFlow {
    private val allowedTransitions = mapOf(
        TransactionStatus.PAYMENT_PENDING to setOf(TransactionStatus.PAYMENT_AUTHORIZED, TransactionStatus.CANCELLED),
        TransactionStatus.PAYMENT_AUTHORIZED to setOf(TransactionStatus.AUTHENTICATION_PENDING, TransactionStatus.REFUND_PENDING, TransactionStatus.CANCELLED),
        TransactionStatus.AUTHENTICATION_PENDING to setOf(TransactionStatus.AUTHENTICATED, TransactionStatus.AUTHENTICATION_FAILED, TransactionStatus.REFUND_PENDING),
        TransactionStatus.AUTHENTICATED to setOf(TransactionStatus.READY_TO_SHIP, TransactionStatus.REFUND_PENDING),
        TransactionStatus.AUTHENTICATION_FAILED to setOf(TransactionStatus.REFUND_PENDING),
        TransactionStatus.READY_TO_SHIP to setOf(TransactionStatus.SHIPPED, TransactionStatus.REFUND_PENDING),
        TransactionStatus.SHIPPED to setOf(TransactionStatus.DELIVERED, TransactionStatus.DISPUTED),
        TransactionStatus.DELIVERED to setOf(TransactionStatus.COMPLETED, TransactionStatus.DISPUTED),
        TransactionStatus.DISPUTED to setOf(TransactionStatus.COMPLETED, TransactionStatus.REFUND_PENDING),
        TransactionStatus.REFUND_PENDING to setOf(TransactionStatus.REFUNDED),
        TransactionStatus.COMPLETED to emptySet(),
        TransactionStatus.REFUNDED to emptySet(),
        TransactionStatus.CANCELLED to emptySet()
    )

    fun canTransition(from: TransactionStatus, to: TransactionStatus): Boolean =
        to in allowedTransitions.getValue(from)
}
