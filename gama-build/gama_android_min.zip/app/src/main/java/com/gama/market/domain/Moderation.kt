package com.gama.market.domain

enum class ReportReason(val label: String) {
    SUSPECTED_COUNTERFEIT("Posible falsificación"),
    MISLEADING_DESCRIPTION("Descripción engañosa"),
    STOLEN_ITEM_CONCERN("Posible artículo robado"),
    ABUSIVE_BEHAVIOR("Comportamiento abusivo"),
    OTHER("Otro")
}

data class ListingReport(
    val id: String,
    val productId: String,
    val reason: ReportReason,
    val note: String,
    val createdAtMillis: Long
)
