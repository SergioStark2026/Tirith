package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.UniversePreference

@Composable
fun UniverseOnboardingScreen(onChoose: (UniversePreference) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("GAMA", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
        Text("Dos universos. Una sola experiencia de lujo.", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(28.dp))
        UniverseCard("ÉCLAT", "Moda, bolsos y complementos", Icons.Default.Diamond) { onChoose(UniversePreference.ECLAT) }
        Spacer(Modifier.height(14.dp))
        UniverseCard("FORGE", "Relojería y tecnología premium", Icons.Default.Watch) { onChoose(UniversePreference.FORGE) }
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = { onChoose(UniversePreference.ALL) }, modifier = Modifier.fillMaxWidth()) {
            Text("Explorar ambos universos")
        }
    }
}

@Composable
private fun UniverseCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(22.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Icon(icon, contentDescription = null)
            Column {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(subtitle)
            }
        }
    }
}
