package com.gama.market.util

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import kotlin.math.abs

sealed interface PhotoQualityResult {
    data object Good : PhotoQualityResult
    data class Bad(val reason: String) : PhotoQualityResult
}

fun validateListingPhoto(context: Context, uri: Uri): PhotoQualityResult {
    val resolver = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        ?: return PhotoQualityResult.Bad("No se pudo leer la foto")

    if (bounds.outWidth < 900 || bounds.outHeight < 900) {
        return PhotoQualityResult.Bad("Acércate menos: necesitamos al menos 900 px por lado")
    }

    val sample = when {
        maxOf(bounds.outWidth, bounds.outHeight) > 4000 -> 8
        maxOf(bounds.outWidth, bounds.outHeight) > 2000 -> 4
        else -> 2
    }
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    val bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        ?: return PhotoQualityResult.Bad("No se pudo analizar la foto")

    var total = 0.0
    var total2 = 0.0
    var edges = 0.0
    var count = 0
    val step = maxOf(1, minOf(bitmap.width, bitmap.height) / 120)

    fun lum(x: Int, y: Int): Double {
        val c = bitmap.getPixel(x, y)
        val r = (c shr 16) and 0xff
        val g = (c shr 8) and 0xff
        val b = c and 0xff
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    var y = step
    while (y < bitmap.height - step) {
        var x = step
        while (x < bitmap.width - step) {
            val l = lum(x, y)
            total += l
            total2 += l * l
            edges += abs(lum(x + step, y) - lum(x - step, y)) + abs(lum(x, y + step) - lum(x, y - step))
            count++
            x += step
        }
        y += step
    }
    bitmap.recycle()

    if (count == 0) return PhotoQualityResult.Bad("No se pudo analizar la foto")
    val mean = total / count
    val variance = total2 / count - mean * mean
    val edgeEnergy = edges / count

    return when {
        mean < 35 -> PhotoQualityResult.Bad("La foto está demasiado oscura")
        mean > 235 -> PhotoQualityResult.Bad("La foto está sobreexpuesta")
        variance < 120 -> PhotoQualityResult.Bad("Falta contraste; cambia la iluminación")
        edgeEnergy < 6 -> PhotoQualityResult.Bad("La imagen parece desenfocada; repite la toma")
        else -> PhotoQualityResult.Good
    }
}
