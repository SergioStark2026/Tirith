package com.gama.market.data

import com.gama.market.domain.*

object FakeCatalog {
    val products = listOf(
        Product(
            id = "lv-neverfull-mm", brand = "Louis Vuitton", model = "Neverfull MM Monogram", priceCents = 129_000,
            condition = ProductCondition.VERY_GOOD,
            verification = setOf(VerificationLevel.IDENTITY, VerificationLevel.DOCUMENTED, VerificationLevel.DIGITAL_AUTH),
            sellerId = "seller-1", sellerName = "Atelier BCN", sellerVerified = true, sellerType = SellerType.PROFESSIONAL, locationLabel = "Barcelona",
            description = "Bolso con uso cuidado, asas en muy buen estado y documentación disponible.",
            universe = MarketUniverse.ECLAT, category = ProductCategory.BAGS
        ),
        Product(
            id = "loewe-puzzle-small", brand = "Loewe", model = "Puzzle Small", priceCents = 175_000,
            condition = ProductCondition.EXCELLENT,
            verification = setOf(VerificationLevel.IDENTITY, VerificationLevel.DOCUMENTED, VerificationLevel.DIGITAL_AUTH, VerificationLevel.FINGERPRINT),
            sellerId = "seller-2", sellerName = "Marta V.", sellerVerified = true, locationLabel = "Madrid",
            description = "Muy poco uso. Incluye dust bag y comprobante de compra.",
            universe = MarketUniverse.ECLAT, category = ProductCategory.BAGS
        ),
        Product(
            id = "omega-seamaster", brand = "Omega", model = "Seamaster Diver 300M", priceCents = 485_000,
            condition = ProductCondition.EXCELLENT,
            verification = setOf(VerificationLevel.IDENTITY, VerificationLevel.DOCUMENTED, VerificationLevel.DIGITAL_AUTH),
            sellerId = "seller-4", sellerName = "Vault Watches", sellerVerified = true, sellerType = SellerType.PROFESSIONAL, locationLabel = "Barcelona",
            description = "Reloj cuidado con caja, documentación y número de serie documentado.",
            universe = MarketUniverse.FORGE, category = ProductCategory.WATCHES
        ),
        Product(
            id = "leica-q3", brand = "Leica", model = "Q3", priceCents = 520_000,
            condition = ProductCondition.VERY_GOOD,
            verification = setOf(VerificationLevel.IDENTITY, VerificationLevel.DOCUMENTED),
            sellerId = "seller-5", sellerName = "Optic House", sellerVerified = true, sellerType = SellerType.PROFESSIONAL, locationLabel = "Madrid",
            description = "Cámara premium con uso ligero, accesorios originales y documentación.",
            universe = MarketUniverse.FORGE, category = ProductCategory.PREMIUM_TECH
        )
    )
}
