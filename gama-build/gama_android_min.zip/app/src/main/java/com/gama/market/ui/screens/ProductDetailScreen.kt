package com.gama.market.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gama.market.domain.*
import com.gama.market.ui.components.ProductImage

@Composable
fun ProductDetailScreen(
    product: Product,
    favorite: Boolean,
    isOwnListing: Boolean,
    onToggleFavorite: () -> Unit,
    onBack: () -> Unit,
    onBuy: () -> Unit,
    onOffer: (Int) -> Boolean,
    onReport: (ReportReason, String) -> Boolean
) {
    var showOffer by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }
    var offer by remember { mutableStateOf((MarketplacePolicy.minimumOfferCents(product.priceCents) / 100).toString()) }
    var message by remember { mutableStateOf<String?>(null) }
    val fees = remember(product.priceCents) { MarketplaceEconomics.fees(product.priceCents) }
    val authRoute = remember(product.id, product.priceCents, product.category) { TrustPolicy.authenticationRoute(product) }

    Scaffold(
        topBar = {
            Surface(shadowElevation = 1.dp) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onBack) { Text("Atrás") }
                    Text(product.brand, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = onToggleFavorite) { Text(if (favorite) "♥" else "♡") }
                }
            }
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                if (isOwnListing) {
                    Text("Este anuncio es tuyo", Modifier.fillMaxWidth().padding(20.dp), fontWeight = FontWeight.Bold)
                } else {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { showOffer = true }, modifier = Modifier.weight(1f)) { Text("Hacer oferta") }
                        Button(onClick = onBuy, modifier = Modifier.weight(1f)) { Text("Comprar") }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                ProductImage(product.photos.firstOrNull()?.uri, Modifier.fillMaxWidth().height(280.dp))
                Spacer(Modifier.height(12.dp))
                Text("${product.universe.label.uppercase()} · ${product.category.label.uppercase()}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                Text(product.brand.uppercase(), style = MaterialTheme.typography.labelLarge)
                Text(product.model, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(product.displayPrice, style = MaterialTheme.typography.headlineSmall)
                Text(product.condition.label)
            }
            item {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Protección GAMA", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("✓ Identidad del vendedor")
                        Text("✓ ${authRoute.label}")
                        product.verification.filter { it != VerificationLevel.IDENTITY }.forEach { Text("✓ ${it.label}") }
                        Text("El vendedor cobra solo cuando la operación queda completada.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (!isOwnListing) item {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Total al comprar", fontWeight = FontWeight.Bold)
                        Text("Artículo: ${fees.itemPriceCents / 100} €")
                        Text("Protección/autenticación: ${fees.buyerProtectionFeeCents / 100} €")
                        Text("Total: ${fees.buyerTotalCents / 100} €", fontWeight = FontWeight.Bold)
                    }
                }
            }
            item { Text("Descripción", fontWeight = FontWeight.Bold); Text(product.description) }
            item {
                Text("Vendedor", fontWeight = FontWeight.Bold)
                Text("${product.sellerName} · ${product.locationLabel}")
                Text(product.sellerType.label, color = MaterialTheme.colorScheme.secondary)
                Text(if (product.sellerVerified) "Identidad verificada" else "Identidad pendiente", color = MaterialTheme.colorScheme.secondary)
            }
            if (!isOwnListing) item { TextButton(onClick = { showReport = true }) { Text("Reportar anuncio") } }
            message?.let { item { Text(it, color = MaterialTheme.colorScheme.secondary) } }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    if (showOffer) {
        AlertDialog(
            onDismissRequest = { showOffer = false },
            title = { Text("Hacer una oferta") },
            text = {
                Column {
                    Text("La oferta mínima es ${MarketplacePolicy.minimumOfferCents(product.priceCents) / 100} €.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = offer, onValueChange = { offer = it.filter(Char::isDigit) }, label = { Text("Oferta (€)") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cents = (offer.toIntOrNull() ?: 0) * 100
                    if (onOffer(cents)) { showOffer = false; message = "Oferta enviada. El vendedor debe aceptarla antes del pago." }
                    else message = "La oferta debe estar entre el mínimo permitido y el precio publicado."
                }) { Text("Enviar oferta") }
            },
            dismissButton = { TextButton(onClick = { showOffer = false }) { Text("Cancelar") } }
        )
    }

    if (showReport) {
        var reason by remember { mutableStateOf(ReportReason.SUSPECTED_COUNTERFEIT) }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showReport = false },
            title = { Text("Reportar anuncio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReportReason.entries.forEach { r ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = reason == r, onClick = { reason = r }); Text(r.label)
                        }
                    }
                    OutlinedTextField(note, { note = it }, label = { Text("Detalle opcional") }, maxLines = 3)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (onReport(reason, note)) message = "Reporte recibido para revisión."
                    showReport = false
                }) { Text("Enviar") }
            },
            dismissButton = { TextButton(onClick = { showReport = false }) { Text("Cancelar") } }
        )
    }
}
