package com.gama.market.domain

object MarketplacePolicy {
    const val MIN_LISTING_PRICE_CENTS = 40_000
    const val MAX_OFFER_DISCOUNT_PERCENT = 10
    const val REQUIRED_PHOTO_COUNT = 6

    private val eclatBrands = linkedSetOf(
        "Louis Vuitton", "Gucci", "Chanel", "Prada", "Dior",
        "Loewe", "Saint Laurent", "Bottega Veneta", "Celine", "Fendi"
    )
    private val watchBrands = linkedSetOf("Rolex", "Omega", "TAG Heuer", "Tudor", "Breitling", "Cartier")
    private val techBrands = linkedSetOf("Apple", "Leica", "Bang & Olufsen", "Devialet", "Hasselblad")

    val allowedBrands: Set<String> = eclatBrands + watchBrands + techBrands

    fun categoriesFor(universe: MarketUniverse): List<ProductCategory> = ProductCategory.entries.filter { it.universe == universe }

    fun brandsFor(category: ProductCategory): Set<String> = when (category) {
        ProductCategory.BAGS, ProductCategory.FASHION_ACCESSORIES -> eclatBrands
        ProductCategory.WATCHES -> watchBrands
        ProductCategory.PREMIUM_TECH -> techBrands
    }

    fun minimumOfferCents(priceCents: Int): Int {
        require(priceCents > 0) { "priceCents must be positive" }
        return ((priceCents.toLong() * (100 - MAX_OFFER_DISCOUNT_PERCENT)) / 100L).toInt()
    }

    fun isOfferAllowed(priceCents: Int, offerCents: Int): Boolean =
        priceCents > 0 && offerCents > 0 && offerCents in minimumOfferCents(priceCents)..priceCents

    fun validateListing(draft: ListingDraft): ListingValidation = when {
        draft.category.universe != draft.universe -> ListingValidation.Invalid("Categoría incompatible con el universo")
        draft.brand !in brandsFor(draft.category) -> ListingValidation.Invalid("Marca no admitida en esta categoría")
        draft.model.trim().length < 2 -> ListingValidation.Invalid("Indica el modelo")
        draft.priceCents < MIN_LISTING_PRICE_CENTS -> ListingValidation.Invalid("Precio mínimo: 400 €")
        draft.description.trim().length < 20 -> ListingValidation.Invalid("Describe el estado con algo más de detalle")
        draft.photos.map { it.kind }.distinct().size < REQUIRED_PHOTO_COUNT -> ListingValidation.Invalid("Faltan fotos guiadas")
        draft.photos.any { it.uri.isBlank() } -> ListingValidation.Invalid("Hay una foto inválida")
        else -> ListingValidation.Valid
    }
}

sealed interface ListingValidation {
    data object Valid : ListingValidation
    data class Invalid(val reason: String) : ListingValidation
}
