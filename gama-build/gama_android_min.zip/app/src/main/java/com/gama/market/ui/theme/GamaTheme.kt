package com.gama.market.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.gama.market.domain.UniversePreference

private val NeutralColors = lightColorScheme(
    primary = Color(0xFF171717), onPrimary = Color.White,
    secondary = Color(0xFF9A7B2F), background = Color(0xFFFAF8F2),
    surface = Color.White, surfaceVariant = Color(0xFFF1EEE5), onSurface = Color(0xFF171717), outline = Color(0xFFD8D1C1)
)

private val EclatColors = lightColorScheme(
    primary = Color(0xFF2E232B), onPrimary = Color.White,
    secondary = Color(0xFFB4975A), background = Color(0xFFFCF8F6),
    surface = Color(0xFFFFFCFA), surfaceVariant = Color(0xFFF3ECEB), onSurface = Color(0xFF2E232B), outline = Color(0xFFD9CBC8)
)

private val ForgeColors = lightColorScheme(
    primary = Color(0xFF171717), onPrimary = Color.White,
    secondary = Color(0xFF8A6747), background = Color(0xFFF4F1EC),
    surface = Color(0xFFFCFBF8), surfaceVariant = Color(0xFFEAE5DE), onSurface = Color(0xFF171717), outline = Color(0xFFBDB5AA)
)

@Composable
fun GamaTheme(preference: UniversePreference = UniversePreference.ALL, content: @Composable () -> Unit) {
    val colors = when (preference) {
        UniversePreference.ECLAT -> EclatColors
        UniversePreference.FORGE -> ForgeColors
        UniversePreference.ALL -> NeutralColors
    }
    MaterialTheme(colorScheme = colors, content = content)
}
