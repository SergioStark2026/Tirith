package com.gama.market.domain

enum class MarketUniverse(val label: String, val subtitle: String) {
    ECLAT("Éclat", "Moda y complementos"),
    FORGE("Forge", "Relojería y tecnología")
}

enum class UniversePreference(val label: String) {
    ECLAT("Éclat"), FORGE("Forge"), ALL("Todo")
}

enum class ProductCategory(val label: String, val universe: MarketUniverse) {
    BAGS("Bolsos", MarketUniverse.ECLAT),
    FASHION_ACCESSORIES("Accesorios", MarketUniverse.ECLAT),
    WATCHES("Relojes", MarketUniverse.FORGE),
    PREMIUM_TECH("Tecnología premium", MarketUniverse.FORGE)
}

enum class ProductCondition(val label: String) {
    EXCELLENT("Excelente"), VERY_GOOD("Muy bueno"), GOOD("Bueno")
}

enum class VerificationLevel(val label: String) {
    IDENTITY("Vendedor verificado"),
    DOCUMENTED("Producto documentado"),
    DIGITAL_AUTH("Autenticación digital"),
    FINGERPRINT("Huella del artículo")
}

enum class PhotoKind(val label: String, val hint: String) {
    FRONT("Frontal", "Artículo completo, recto y con buena luz"),
    BACK("Trasera", "Vista posterior completa"),
    LOGO("Marca", "Logotipo, grabado o firma nítida"),
    SERIAL("Serie", "Número de serie, etiqueta o código"),
    INTERIOR("Interior / perfil", "Interior si aplica; si no, perfil o lateral"),
    DETAIL("Detalle", "Herrajes, material, esquinas o signos de uso")
}

data class ProductPhoto(val kind: PhotoKind, val uri: String, val sha256: String? = null)

data class Product(
    val id: String,
    val brand: String,
    val model: String,
    val priceCents: Int,
    val condition: ProductCondition,
    val verification: Set<VerificationLevel>,
    val sellerId: String,
    val sellerName: String,
    val sellerVerified: Boolean,
    val sellerType: SellerType = SellerType.PRIVATE,
    val locationLabel: String,
    val description: String,
    val universe: MarketUniverse = MarketUniverse.ECLAT,
    val category: ProductCategory = ProductCategory.BAGS,
    val photos: List<ProductPhoto> = emptyList(),
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    val displayPrice: String get() = "%,d €".format(priceCents / 100)
}

enum class AccountVerification(val label: String) {
    UNVERIFIED("Sin verificar"), PENDING("Verificación pendiente"), VERIFIED("Identidad verificada")
}

data class UserProfile(
    val id: String = "local-user",
    val displayName: String = "Mi perfil",
    val email: String = "",
    val verification: AccountVerification = AccountVerification.UNVERIFIED,
    val salesCount: Int = 0,
    val purchasesCount: Int = 0,
    val universePreference: UniversePreference = UniversePreference.ALL,
    val onboardingComplete: Boolean = false,
    val sellerType: SellerType = SellerType.PRIVATE,
    val foundingSeller: Boolean = false
)

data class ListingDraft(
    val brand: String,
    val model: String,
    val priceCents: Int,
    val condition: ProductCondition,
    val description: String,
    val locationLabel: String,
    val photos: List<ProductPhoto>,
    val universe: MarketUniverse = MarketUniverse.ECLAT,
    val category: ProductCategory = ProductCategory.BAGS
)

enum class OfferStatus(val label: String) {
    PENDING("Pendiente"), ACCEPTED("Aceptada"), REJECTED("Rechazada"), CANCELLED("Cancelada")
}

data class Offer(
    val id: String,
    val productId: String,
    val productLabel: String,
    val amountCents: Int,
    val status: OfferStatus,
    val createdAtMillis: Long
) {
    val displayAmount: String get() = "%,d €".format(amountCents / 100)
}

data class Order(
    val id: String,
    val productId: String,
    val productLabel: String,
    val amountCents: Int,
    val status: TransactionStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val sellerFeeCents: Int = 0,
    val buyerProtectionFeeCents: Int = 0,
    val paymentProviderRef: String? = null,
    val authenticationRef: String? = null,
    val shippingProviderRef: String? = null
) {
    val displayAmount: String get() = "%,d €".format(amountCents / 100)
}
